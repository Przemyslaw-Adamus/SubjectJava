public interface Set {
    public void set();
}
